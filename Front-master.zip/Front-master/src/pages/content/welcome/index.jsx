import React from "react";
import Banner from "../../../components/Banner";

const Welcome = () => {
    return (
        <>
            <Banner />
        </>
    );
}

export default Welcome;